﻿namespace PatientDataMicroservice
{
    public enum FileFormat
    {
        Json,
        Txt,
        Xml
    }
}
