﻿namespace AppModels
{
    public interface IModel : IData, IOperations
    {
    }
}
