﻿namespace AppModels
{
    public interface IOperations
    {
        void LoadDrugList();
        void LoadDoctorList();
        void LoadPrescriptionList();
    }
}
