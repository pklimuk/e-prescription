﻿namespace DrugsDataMicroService
{
    public enum DrugType
    {
        Dietary_Supplement,
        Antibiotic,
        CNS_Stimulant,
        Pain_Killers,
        Pyrexia,
        Lithium,
    }
}
