﻿namespace DrugsDataMicroService
{
    public enum FileFormat
    {
        Json,
        Txt,
        Xml
    }
}
