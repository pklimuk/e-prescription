﻿namespace DoctorsDataMicroservice
{
    public enum DoctorSpecialisation
    {
        Therapist,
        Surgeon,
        Ophthalmologist,
        Pharmacist
    }
}
