﻿namespace DoctorsDataMicroservice
{
    public enum FileFormat
    {
        Json,
        Txt,
        Xml
    }
}
