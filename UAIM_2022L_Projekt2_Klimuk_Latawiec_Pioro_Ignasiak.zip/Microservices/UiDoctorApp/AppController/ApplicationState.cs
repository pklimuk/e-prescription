﻿namespace AppController
{
    public enum ApplicationState
    {
        List,
        Map
    }
}
