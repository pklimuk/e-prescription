﻿namespace PrescriptionDataMicroservice
{
    public enum FileFormat
    {
        Json,
        Txt,
        Xml
    }
}
